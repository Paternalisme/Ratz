This 3D model is created by TripRay company.

If you need any technical support or have other questions about this 3D model, please write: support@tripray.com.

Also in our 3D market place (www.tripray.com) you can buy or download free a huge quantity of 3D models (in 6 different formats), digital textures and photographies.
All content is created by our company. You will be pleasantly surprised by low prices and the quantity of free objects.

Best regards, TripRay company
Step by step in 3Dimension
www.tripray.com